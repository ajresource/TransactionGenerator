#!/bin/bash

read testcase; read des; read sql
#echo "$testcase" "$des" "$sql"
echo "TESTCASE=$testcase" > $testcase
echo "DESCRIPTION=$des" >> $testcase
echo "SQL=$sql" >> $testcase
